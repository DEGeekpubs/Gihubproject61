package app;

public enum Action {
	INSERT, DELETE, UPDATE
}

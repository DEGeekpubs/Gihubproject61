package storage;

public interface ITuple {

	public void addCell(Cell c);

	public void setPrimaryKey(Object pk);

}

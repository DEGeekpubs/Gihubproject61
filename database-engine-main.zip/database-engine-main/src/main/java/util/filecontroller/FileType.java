package util.filecontroller;

public enum FileType {
	TABLE, PAGE
}
